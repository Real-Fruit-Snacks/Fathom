# adb uninstall

> Uninstall a package.
> More information: <https://manned.org/adb>.

- Uninstall a package:

`adb uninstall <com.example.app>`

- Uninstall a package, but keep user data:

`adb uninstall -k <com.example.app>`
