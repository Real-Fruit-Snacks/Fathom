# calligraflow

> Calligra's flowchart and diagram application.
> See also: `calligrastage`, `calligrawords`, `calligrasheets`.
> More information: <https://manned.org/calligraflow>.

- Launch the flowchart and diagram application:

`calligraflow`

- Open a specific file:

`calligraflow <path/to/file>`

- Display help or version:

`calligraflow --<help|version>`
