# adb devices

> List connected Android devices.
> More information: <https://manned.org/adb>.

- List devices:

`adb devices`

- List devices and their system info:

`adb devices -l`
