# bird

> BIRD Internet Routing Daemon.
> Routing daemon with support for BGP, OSPF, Babel and others.
> More information: <https://bird.network.cz/>.

- Start Bird with a specific configuration file:

`bird -c <path/to/bird.conf>`

- Start Bird as a specific user and group:

`bird -u <username> -g <group>`
