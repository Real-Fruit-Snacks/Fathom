# comma

> This command is an alias of `,`.

- View documentation for the original command:

`tldr ,`
