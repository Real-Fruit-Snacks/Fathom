# brave

> This command is an alias of `chromium`.
> More information: <https://support.brave.com/hc/en-us/articles/360044860011-How-Do-I-Use-Command-Line-Flags-in-Brave>.

- View documentation for the original command:

`tldr chromium`
