// Cheatsheet index - list of commands with available cheatsheets
window.cheatsheetIndex = [
    'ls',
    'grep', 
    'find',
    'tar',
    'curl',
    'sed',
    'awk',
    'git',
    'docker',
    'ssh',
    'rsync',
    'wget'
];